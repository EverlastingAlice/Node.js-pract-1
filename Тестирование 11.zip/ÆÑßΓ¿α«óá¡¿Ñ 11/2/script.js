const fs = require('fs');

fs.readFile('data.csv', 'utf8', (err, data) => {
  if (err) {
    console.error('Ошибка чтения файла:', err);
    return;
  }

  const lines = data.trim().split('\n');
  
  // Проверяем наличие заголовков и данных
  if (lines.length < 2) {
    console.log('Недостаточно данных в файле');
    return;
  }

  // Парсим заголовки с очисткой пробелов
  const headers = lines[0]
    .split(',')
    .map(header => header.trim().toLowerCase()); // Приводим к нижнему регистру для единообразия

  // Проверяем корректность заголовков
  if (headers.length !== 3 || !headers.includes('name') || 
      !headers.includes('age') || !headers.includes('city')) {
    console.error('Неверный формат заголовков CSV');
    return;
  }

  // Парсим данные
  const users = lines.slice(1)
    .filter(line => line.trim() !== '') // Пропускаем пустые строки
    .map(line => {
      const values = line.split(',').map(value => value.trim());
      
      // Пропускаем строки с неполными данными
      if (values.length < 3) return null;

      return {
        [headers[0]]: values[0],
        [headers[1]]: parseInt(values[1], 10) || 0, // Защита от NaN
        [headers[2]]: values[2]
      };
    })
    .filter(user => user !== null); // Удаляем некорректные записи

  // Сортируем и выводим результат
  users.sort((a, b) => a.age - b.age);
  console.log(users);
});