const fs = require('fs');

fs.readFile('log.txt', 'utf8', (err, data) => {
  if (err) {
    console.error('Ошибка чтения файла:', err);
    return;
  }

  const lines = data.split('\n').filter(line => line.trim() !== '');
  const stats = { INFO: 0, WARNING: 0, ERROR: 0 };
  const errors = [];

  // Исправленное регулярное выражение
  const logPattern = /^\s*\[(.*?)\]\s+\[(.*?)\]\s+(.*)\s*$/;

  lines.forEach(line => {
    const match = line.match(logPattern);
    
    if (match) {
      const date = match[1].trim();
      const type = match[2].trim().toUpperCase();
      const message = match[3].trim();
      
      if (stats.hasOwnProperty(type)) {
        stats[type]++;
      } else {
        console.log(`Неизвестный тип лога: ${type}`);
        return;
      }

      if (type === 'ERROR') {
        errors.push(`[${date}] ${message}`);
      }
    } else {
      console.log(`Некорректная строка: ${line}`);
    }
  });

  console.log('Статистика по логам:');
  console.log(`INFO: ${stats.INFO}`);
  console.log(`WARNING: ${stats.WARNING}`);
  console.log(`ERROR: ${stats.ERROR}`);
  
  console.log('\nСписок ошибок:');
  errors.forEach(error => console.log(error));
});